test = {   'name': 'q9',
    'points': None,
    'suites': [{'cases': [{'code': '>>> int(true_percentage_intervals)\n4750', 'hidden': True, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
