test = {   'name': 'q1',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(one_resampled_percentage(votes)) in set([float, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 35 <= one_resampled_percentage(votes) <= 65\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.random.seed(123)\n>>> one_resampled_percentage(votes)\n51.6', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
