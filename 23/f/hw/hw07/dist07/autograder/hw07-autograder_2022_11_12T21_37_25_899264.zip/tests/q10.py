test = {   'name': 'q10',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> restaurants_tied in [1,2,3]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> restaurants_tied == 2\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
