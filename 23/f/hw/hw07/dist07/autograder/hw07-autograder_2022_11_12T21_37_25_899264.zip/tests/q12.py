test = {   'name': 'q12',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> cutoff_ten_percent in [1,2,3]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> cutoff_ten_percent == 3\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
