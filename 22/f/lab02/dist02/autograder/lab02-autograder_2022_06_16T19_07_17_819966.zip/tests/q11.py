test = {   'name': 'q11',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> durham_farmers_markets.num_rows\n5', 'hidden': False, 'locked': False},
                                   {'code': ">>> all('Durham' == durham_farmers_markets['city'])\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
