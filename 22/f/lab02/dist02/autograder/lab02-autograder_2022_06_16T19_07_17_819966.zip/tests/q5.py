test = {   'name': 'q5',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> num_farmers_markets_columns == farmers_markets.num_columns\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
