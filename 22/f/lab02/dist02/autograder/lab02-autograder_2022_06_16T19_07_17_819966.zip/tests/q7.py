test = {   'name': 'q7',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> farmers_markets_locations.num_rows\n8546', 'hidden': False, 'locked': False},
                                   {'code': '>>> farmers_markets_locations.num_columns\n5', 'hidden': False, 'locked': False},
                                   {'code': ">>> sorted(farmers_markets_locations.labels) == ['MarketName', 'State', 'city', 'x', 'y']\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
