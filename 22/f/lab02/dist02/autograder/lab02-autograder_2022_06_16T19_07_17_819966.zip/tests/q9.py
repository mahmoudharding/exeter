test = {   'name': 'q9',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(farmers_markets_locations_by_longitude, tables.Table)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': ">>> list(farmers_markets_locations_by_longitude.column('x').take(range(3))) == [-64.7043, -64.7789, -64.8799]\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
