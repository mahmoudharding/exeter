test = {   'name': 'q13',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> proportion_in_20th_century\n0.64', 'hidden': False, 'locked': False}, {'code': '>>> proportion_in_21st_century\n0.36', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
