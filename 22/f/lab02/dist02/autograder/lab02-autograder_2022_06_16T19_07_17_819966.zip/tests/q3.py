test = {   'name': 'q3',
    'points': None,
    'suites': [{'cases': [{'code': '>>> sine_of_pi_over_four\n0.7071067811865475', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
