test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> near_twenty != math.e**math.pi\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> near_twenty\n19.99909997918947', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
