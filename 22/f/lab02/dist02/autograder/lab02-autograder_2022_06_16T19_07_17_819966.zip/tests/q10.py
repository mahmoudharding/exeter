test = {   'name': 'q10',
    'points': None,
    'suites': [   {   'cases': [{'code': ">>> farmers_markets_locations_by_latitude.first('y') == 64.86275\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
