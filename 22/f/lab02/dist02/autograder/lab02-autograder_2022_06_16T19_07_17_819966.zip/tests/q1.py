test = {'name': 'q1', 'points': None, 'suites': [{'cases': [{'code': '>>> new_year\n2023', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
