test = {   'name': 'q6',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> num_farmers_markets_rows == farmers_markets.num_rows\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
