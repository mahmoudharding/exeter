test = {   'name': 'q8',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(simulation_and_statistic(model_proportions, .5), float)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> 0 <= simulation_and_statistic(model_proportions, .5) <= 25\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
