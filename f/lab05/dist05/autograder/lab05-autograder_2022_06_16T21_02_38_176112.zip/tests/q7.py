test = {   'name': 'q7',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> expected_proportion_correct == expected_proportion_incorrect\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> len(np.unique(model_proportions))\n1', 'hidden': False, 'locked': False},
                                   {'code': '>>> sum(model_proportions)\n1.0', 'hidden': False, 'locked': False},
                                   {   'code': '>>> # Make sure you take the item\n'
                                               '>>> # from the array that corrresponds\n'
                                               '>>> # to the proportion correct simulations\n'
                                               '>>> isinstance(simulation_proportion_correct, float)\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False},
                                   {'code': '>>> 0 <= one_statistic <= 25\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
