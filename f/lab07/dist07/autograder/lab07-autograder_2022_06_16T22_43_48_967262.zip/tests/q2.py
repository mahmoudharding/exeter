test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(percentages_in_resamples())\n2500', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.random.seed(123)\n>>> percentages_in_resamples().item(0)\n51.6', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.random.seed(123)\n>>> percentages_in_resamples().item(10)\n50.0', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
