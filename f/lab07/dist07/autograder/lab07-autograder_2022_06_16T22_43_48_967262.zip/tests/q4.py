test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> type(one_resampled_difference(votes)) in set([float, np.float64])\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> -6 <= float(one_resampled_difference(votes)) <= 15\nTrue', 'hidden': True, 'locked': False},
                                   {'code': '>>> np.random.seed(123)\n>>> np.isclose( float(one_resampled_difference(votes)), 3.1999999999999957)\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
