test = {   'name': 'q11',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> cutoff_one_percent in [1,2,3]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> cutoff_one_percent\n1', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
