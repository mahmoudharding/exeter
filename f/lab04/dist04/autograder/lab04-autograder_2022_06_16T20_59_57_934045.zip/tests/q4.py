test = {   'name': 'q4',
    'points': None,
    'suites': [{'cases': [{'code': ">>> num_non_vowels('go unicorns') == 7\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
