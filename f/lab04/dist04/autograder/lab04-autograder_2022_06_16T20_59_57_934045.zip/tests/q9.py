test = {   'name': 'q9',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> convert_pay_string_to_number('$100,000,000 ') == 100000000.0\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> convert_pay_string_to_number('$23,000,000 ') == 23000000.0\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
