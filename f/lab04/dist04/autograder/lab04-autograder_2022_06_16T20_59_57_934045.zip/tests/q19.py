test = {   'name': 'q19',
    'points': None,
    'suites': [{'cases': [{'code': '>>> num_ceos_more_than_10_million\n12', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
