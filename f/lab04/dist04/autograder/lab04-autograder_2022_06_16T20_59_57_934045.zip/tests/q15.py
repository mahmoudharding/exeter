test = {   'name': 'q15',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> ceo_salary_percent.num_columns\n14', 'hidden': False, 'locked': False},
                                   {   'code': ">>> ceo_salary_percent.labels == ('Company',\n"
                                               "...                               'Ticker',\n"
                                               "...                               'City',\n"
                                               "...                               'Name', \n"
                                               "...                               'Salary', \n"
                                               "...                               'Bonus',\n"
                                               "...                               'Stock',\n"
                                               "...                               'Options',\n"
                                               "...                               'Incentive',\n"
                                               "...                               'Retirement',\n"
                                               "...                               'Other',\n"
                                               "...                               'Total Pay',\n"
                                               "...                               'Total Pay ($)',\n"
                                               "...                               'Salary (%)'\n"
                                               '...                              )\n'
                                               'True',
                                       'hidden': False,
                                       'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
