test = {   'name': 'q7',
    'points': None,
    'suites': [{'cases': [{'code': ">>> brian_moynihan_pay_string\n'$26,039,213 '", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
