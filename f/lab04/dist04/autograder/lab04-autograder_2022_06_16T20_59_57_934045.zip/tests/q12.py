test = {   'name': 'q12',
    'points': None,
    'suites': [   {   'cases': [   {'code': ">>> 'Total Pay ($)' in compensation.labels\nTrue", 'hidden': False, 'locked': False},
                                   {'code': ">>> compensation.sort('Total Pay ($)', descending=True).column('Total Pay ($)').item(0) == 26039213.0\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
