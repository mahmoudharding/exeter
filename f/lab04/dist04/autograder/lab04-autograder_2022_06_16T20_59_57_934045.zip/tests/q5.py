test = {   'name': 'q5',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> print_kth_top_movie_year(3)\nYear number 3 for total gross movie sales was 2019\n', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
