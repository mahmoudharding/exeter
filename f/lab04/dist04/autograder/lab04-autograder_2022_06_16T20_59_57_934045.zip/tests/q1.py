test = {   'name': 'q1',
    'points': None,
    'suites': [{'cases': [{'code': '>>> to_percentage(.35) == 35.0\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
