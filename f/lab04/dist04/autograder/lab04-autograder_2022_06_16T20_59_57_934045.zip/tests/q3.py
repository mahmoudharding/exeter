test = {   'name': 'q3',
    'points': None,
    'suites': [{'cases': [{'code': ">>> disemvowel('datasceince') == 'dtscnc'\nTrue", 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
