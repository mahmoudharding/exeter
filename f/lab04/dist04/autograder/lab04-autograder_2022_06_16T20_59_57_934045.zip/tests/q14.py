test = {   'name': 'q14',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(salary_proportion)\n61', 'hidden': False, 'locked': False},
                                   {'code': '>>> np.isclose(salary_proportion.item(0), 0.05760542762947559)\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
