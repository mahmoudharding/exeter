test = {   'name': 'q2',
    'points': None,
    'suites': [{'cases': [{'code': '>>> a_percentage\n70.71067811865476', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
