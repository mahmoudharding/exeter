test = {   'name': 'q13',
    'points': None,
    'suites': [{'cases': [{'code': '>>> np.isclose(average_total_pay, 6332531.852459016)\nTrue', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
