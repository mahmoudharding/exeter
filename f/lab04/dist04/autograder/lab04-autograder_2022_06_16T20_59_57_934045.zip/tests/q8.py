test = {   'name': 'q8',
    'points': None,
    'suites': [{'cases': [{'code': '>>> brian_moynihan_pay\n26039213.0', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
