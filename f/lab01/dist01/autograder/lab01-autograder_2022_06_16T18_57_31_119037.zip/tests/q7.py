test = {   'name': 'q7',
    'points': None,
    'suites': [{'cases': [{'code': '>>> round(paola_distance_from_average_m, 3)\n0.072', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
