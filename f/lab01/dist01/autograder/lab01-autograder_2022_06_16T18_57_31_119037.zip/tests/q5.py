test = {   'name': 'q5',
    'points': None,
    'suites': [{'cases': [{'code': '>>> seconds_in_a_decade\n315532800', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
