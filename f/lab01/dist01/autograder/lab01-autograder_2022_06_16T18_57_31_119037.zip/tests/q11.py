test = {   'name': 'q11',
    'points': None,
    'suites': [{'cases': [{'code': '>>> min_height_difference\n0.029999999999999805', 'hidden': False, 'locked': False}], 'scored': True, 'setup': '', 'teardown': '', 'type': 'doctest'}]}
