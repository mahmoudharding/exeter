test = {   'name': 'q14',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> len(differences)\n5000', 'hidden': False, 'locked': False},
                                   {'code': '>>> # On average, your test statistic should be close to 0\n>>> abs(np.average(differences)) < 1\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> # Make sure all test statistics are different\n>>> all(differences == differences.item(0)) == False\nTrue', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
