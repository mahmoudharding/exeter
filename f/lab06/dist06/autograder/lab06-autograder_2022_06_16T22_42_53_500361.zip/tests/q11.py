test = {   'name': 'q11',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> isinstance(observed_difference, float)\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(observed_difference, 3)\n1.647', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
