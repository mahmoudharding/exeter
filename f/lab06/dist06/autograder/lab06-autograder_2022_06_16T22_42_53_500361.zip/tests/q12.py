test = {   'name': 'q12',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> round(find_test_stat(helicopters, "Rotor", "Time"),3)\n1.647', 'hidden': False, 'locked': False},
                                   {'code': '>>> round(find_test_stat(helicopters, "Weight", "Time"),3)\n1.0', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
