test = {   'name': 'q9',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> time_means.num_rows\n2', 'hidden': False, 'locked': False},
                                   {'code': '>>> time_means.where("Rotor", "Long").column(1).item(0)\n5.610666666666667', 'hidden': False, 'locked': False},
                                   {'code': '>>> time_means.where("Rotor", "Short").column(1).item(0)\n3.963636363636364', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
