test = {   'name': 'q13',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> np.random.seed(123)\n>>> round(simulate_and_test_statistic(helicopters, "Rotor", "Time"), 3)\n0.323', 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
