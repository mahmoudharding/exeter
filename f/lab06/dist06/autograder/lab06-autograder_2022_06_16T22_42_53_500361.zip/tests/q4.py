test = {   'name': 'q4',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> helicopters.num_rows\n130', 'hidden': False, 'locked': False},
                                   {'code': ">>> all(helicopters.column('Obstruction') == False)\nTrue", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
