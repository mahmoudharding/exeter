test = {   'name': 'q8',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> set(q8).issubset(set([1,2,3,4,5,6,7,8,9]))\nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set(q8) == set([1, 4, 6, 8])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
