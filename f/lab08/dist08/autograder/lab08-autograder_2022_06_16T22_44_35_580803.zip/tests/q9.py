test = {   'name': 'q9',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> SD_of_sample_means in [1,2,3,4]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> SD_of_sample_means\n3', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
