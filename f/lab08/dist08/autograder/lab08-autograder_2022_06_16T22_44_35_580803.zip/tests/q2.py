test = {   'name': 'q2',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> mean_median in [1,2,3]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> mean_median\n2', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
