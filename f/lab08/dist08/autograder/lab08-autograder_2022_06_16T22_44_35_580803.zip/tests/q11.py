test = {   'name': 'q11',
    'points': None,
    'suites': [   {   'cases': [{'code': '>>> q11 in [1,2]\nTrue', 'hidden': False, 'locked': False}, {'code': '>>> q11\n1', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
