test = {   'name': 'q5',
    'points': None,
    'suites': [   {   'cases': [{'code': ">>> np.random.seed(123)\n>>> one_sample_mean(salaries, 'salary', 100)\n81225.33280000002", 'hidden': False, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
