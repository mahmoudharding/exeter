test = {   'name': 'q10',
    'points': None,
    'suites': [   {   'cases': [   {'code': '>>> set(pop_vs_sample).issubset(set([1,2,3,4,5,6])) \nTrue', 'hidden': False, 'locked': False},
                                   {'code': '>>> set(pop_vs_sample) == set([3, 4])\nTrue', 'hidden': True, 'locked': False}],
                      'scored': True,
                      'setup': '',
                      'teardown': '',
                      'type': 'doctest'}]}
